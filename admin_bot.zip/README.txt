
Інструкція запуску бота Grand Mobile Admin Timer:

1. Встановіть Python 3.10+
   https://www.python.org/downloads/

2. Встановіть бібліотеку:
   pip install -r requirements.txt

3. Вставте свій токен від BotFather у файл admin_bot.py:
   BOT_TOKEN = "ТУТ_ВАШ_ТОКЕН"

4. Запустіть бота:
   python admin_bot.py

Бот буде відповідати на команду /admins лише для Telegram ID: 7292634641
